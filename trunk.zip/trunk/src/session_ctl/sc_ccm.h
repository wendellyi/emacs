/*
 * src/session_ctl/sc_ccm.h
 */

#ifndef _SRC_SESSION_CTL_SC_CCM_H_
#define _SRC_SESSION_CTL_SC_CCM_H_

#include "event_driver.h"
#include "sc_session.h"

/* 底层消息分帧处理函数，用于注册 */
void sc_ccm_pool_handler(
    struct ed_client_t * client, void * data, unsigned int * data_len);

int sc_ccm_init(struct ed_t * ed, struct sc_init_t * init);
void sc_ccm_stop(void);

#endif  /* _SRC_SESSION_CTL_SC_CCM_H_ */











